package com.UserManagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserManagement2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
